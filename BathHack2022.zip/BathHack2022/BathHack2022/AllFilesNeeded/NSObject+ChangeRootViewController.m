//
//  NSObject+ChangeRootViewController.m
//  ZNZNew
//
//  Created by xjhuang on 2018/8/29.
//  Copyright © 2018年 xjhuang. All rights reserved.
//

#import "NSObject+ChangeRootViewController.h"

@implementation NSObject (ChangeRootViewController)
- (void)restoreRootViewController:(UIViewController *)rootViewController
{
    typedef void (^Animation)(void);
    UIWindow* window = [UIApplication sharedApplication].windows[0];
    
    rootViewController.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    Animation animation = ^{
        BOOL oldState = [UIView areAnimationsEnabled];
        [UIView setAnimationsEnabled:NO];
        [UIApplication sharedApplication].windows[0].rootViewController = rootViewController;
        [UIView setAnimationsEnabled:oldState];
    };
    
    [UIView transitionWithView:window
                      duration:0.5f
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:animation
                    completion:nil];
}
@end
