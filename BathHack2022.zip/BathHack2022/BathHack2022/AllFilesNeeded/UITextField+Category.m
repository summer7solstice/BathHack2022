//
//  UITextField+Category.m
//  Danfo
//
//  Created by 黄晓军 on 2020/3/16.
//  Copyright © 2020 xjhuang. All rights reserved.
//

#import "UITextField+Category.h"

@implementation UITextField (Category)

- (void)setPlaceHolderColor:(UIColor *)placeHolderColor
{
    self.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.placeholder attributes:@{NSForegroundColorAttributeName: placeHolderColor}];
}
- (UIColor *)placeHolderColor
{
    return nil;
}
@end
