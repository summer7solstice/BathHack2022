//
//  NSObject+HUD.m
//  ZNZNew
//
//  Created by xjhuang on 2018/7/11.
//  Copyright © 2018年 xjhuang. All rights reserved.
//

#import "NSObject+HUD.h"
#define XJ_MAINWINDOW UIApplication.sharedApplication.windows[0]
static const NSInteger ProgressHUDTag = 1000 + 666;
@implementation NSObject (HUD)
/* 文字提示 */
- (void)showToastHUD:(NSString *)string{
    dispatch_async(dispatch_get_main_queue(), ^{
        //显示信息之前，先隐藏已有的HUD
        [self hideProgressHUD];
        MBProgressHUD *HUD = [MBProgressHUD showHUDAddedTo:XJ_MAINWINDOW animated:true];
        HUD.mode = MBProgressHUDModeText;
        HUD.color = [UIColor colorWithHexString:@"#000000" alpha:0.7];
        HUD.detailsLabelText = string;
        HUD.dimBackground = false;
        HUD.removeFromSuperViewOnHide = true;
        [HUD hide:true afterDelay:2];
    });
}
/* 进度条 */
- (void)showProgressHUD{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *HUD = [MBProgressHUD showHUDAddedTo:XJ_MAINWINDOW animated:true];
        HUD.mode = MBProgressHUDModeIndeterminate;
        HUD.color = [UIColor colorWithHexString:@"#000000" alpha:0.7];
        HUD.tag = ProgressHUDTag;
    });
}
- (void)hideProgressHUD{
    dispatch_async(dispatch_get_main_queue(), ^{
        for (MBProgressHUD *HUD in [MBProgressHUD allHUDsForView:XJ_MAINWINDOW]) {
            if (HUD.tag == ProgressHUDTag) {
                [HUD hide:YES];
            }
        }
    });
}
@end
