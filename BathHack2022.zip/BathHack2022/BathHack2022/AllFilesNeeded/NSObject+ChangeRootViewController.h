//
//  NSObject+ChangeRootViewController.h
//  ZNZNew
//
//  Created by xjhuang on 2018/8/29.
//  Copyright © 2018年 xjhuang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (ChangeRootViewController)
- (void)restoreRootViewController:(UIViewController *)rootViewController;
@end
