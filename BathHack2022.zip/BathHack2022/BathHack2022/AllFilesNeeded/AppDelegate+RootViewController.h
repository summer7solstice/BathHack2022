//
//  AppDelegate+RootViewController.h
//  AWJ
//
//  Created by 黄晓军 on 2019/7/9.
//  Copyright © 2019 xjhuang. All rights reserved.
//

#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (RootViewController)
- (void)initializeRootViewControllerWithApplication:(UIApplication *)application;
@end

NS_ASSUME_NONNULL_END
