//
//  SceneDelegate.h
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

