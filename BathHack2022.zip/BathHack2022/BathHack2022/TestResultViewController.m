//
//  TestResultViewController.m
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import "TestResultViewController.h"

@interface TestResultViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *goodImageView;
@property (weak, nonatomic) IBOutlet UIView *sadView;
@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;

@end

@implementation TestResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.haveCravity)
    {
        self.sadView.hidden = NO;
        self.goodImageView.hidden = YES;
    }
    else
    {
        self.sadView.hidden = YES;
        self.goodImageView.hidden = NO;
    }
}
- (IBAction)viewLogButtonClick:(UIButton *)sender {
    if (self.block0) {
        self.block0();
    }
}
- (IBAction)retakeButtonClick:(UIButton *)sender {
    if (self.block1) {
        self.block1();
    }
}

@end
