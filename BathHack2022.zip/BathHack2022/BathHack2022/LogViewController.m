//
//  LogViewController.m
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import "LogViewController.h"
#import "DataCell.h"
@interface LogViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *listArray;
@end

@implementation LogViewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.listArray removeAllObjects];
    [self.listArray addObjectsFromArray:[DataManager sharedManager].getAllData];
    [self.tableView reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.rowHeight = 52;
}
- (NSMutableArray *)listArray
{
    if (!_listArray) {
        _listArray = [NSMutableArray array];
    }
    return _listArray;
}
#pragma mark - TableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.listArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *rid =  @"DataCell";
    DataCell *cell = [tableView dequeueReusableCellWithIdentifier:rid];
    NSDictionary *dict = self.listArray[indexPath.row];
    cell.label0.text = dict[mKey];
    cell.label1.text = dict[cKey];
    cell.label2.text = dict[dKey];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    [tableView deselectRowAtIndexPath:indexPath animated:true];
    
}

@end
