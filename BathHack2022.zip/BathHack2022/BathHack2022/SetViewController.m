//
//  SetViewController.m
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import "SetViewController.h"

@interface SetViewController ()

@end

@implementation SetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
- (IBAction)btnClick:(UIButton *)sender {
    [self showToastHUD:@"Still developing."];
}


@end
