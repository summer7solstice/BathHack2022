//
//  TestViewController.h
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef void(^checkBlock)(void);
@interface TestViewController : UIViewController
@property (nonatomic, copy) checkBlock block;
@end

NS_ASSUME_NONNULL_END
