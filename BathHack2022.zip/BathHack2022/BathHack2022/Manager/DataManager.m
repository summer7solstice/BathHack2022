//
//  DataManager.m
//  BathHack
//
//  Created by xjhuang on 02/04/2022.
//

#import "DataManager.h"
#define kDataKey @"DataKey"
static DataManager *manager = nil;

@implementation DataManager
+ (DataManager *)sharedManager
{
    @synchronized (self) {
        if (!manager) {
            manager = [[DataManager alloc] init];
        }
    }
    return manager;
}
#pragma mark - getter

/* 销毁单例 */
+ (void)deallocManager
{
    manager = nil;
}
#pragma mark - 覆写方法
+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    @synchronized(self) {
        if (manager == nil) {
            manager = [super allocWithZone:zone];
        }
    }
    return manager;
}
-(id)copyWithZone:(struct _NSZone *)zone{
    return manager;
}
-(id)copy{
    return self;
}
-(id)mutableCopy{
    return self;
}

#pragma mark - Funcs
- (void)appendNewData:(NSDictionary *)obj
{
    NSArray *dataArray = [self getAllData];
    NSMutableArray *mutableArray = [NSMutableArray arrayWithArray:dataArray];
    // append the data
    [mutableArray addObject:obj];
    [[NSUserDefaults standardUserDefaults] setBool:mutableArray forKey:kDataKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
- (NSArray *)getAllData
{
    NSArray *dataArray = [[NSUserDefaults standardUserDefaults] objectForKey:kDataKey];
    
    return dataArray;
}
@end
