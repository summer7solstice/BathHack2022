//
//  DataManager.h
//  BathHack
//
//  Created by xjhuang on 02/04/2022.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DataManager : NSObject

+ (DataManager *)sharedManager;

- (void)appendNewData:(NSDictionary *)obj;
- (NSArray *)getAllData;
@end

NS_ASSUME_NONNULL_END
