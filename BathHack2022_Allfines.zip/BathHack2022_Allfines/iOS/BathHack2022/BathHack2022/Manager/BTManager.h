//
//  BTManager.h
//  BathHack
//
//  Created by xjhuang on 02/04/2022.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

NS_ASSUME_NONNULL_BEGIN

@interface BTManager : NSObject<CBCentralManagerDelegate, CBPeripheralDelegate>
+ (BTManager *)sharedManager;

@property (nonatomic, strong) CBCentralManager *cMgr;
@property (nonatomic, strong) CBPeripheral *peripheral;
@end

NS_ASSUME_NONNULL_END
