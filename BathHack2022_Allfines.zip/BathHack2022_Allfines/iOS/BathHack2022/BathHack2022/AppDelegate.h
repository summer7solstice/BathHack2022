//
//  AppDelegate.h
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UITabBarController *tabbarController;

@end

