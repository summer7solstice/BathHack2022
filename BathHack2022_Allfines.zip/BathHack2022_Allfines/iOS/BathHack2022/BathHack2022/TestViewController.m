//
//  TestViewController.m
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import "TestViewController.h"

@interface TestViewController ()
@property (weak, nonatomic) IBOutlet UIButton *checkButton;
@property (weak, nonatomic) IBOutlet UIImageView *checkImage;
@property (weak, nonatomic) IBOutlet UIImageView *inProgressImageView;
@property (weak, nonatomic) IBOutlet UIImageView *completeImageView;
@property (weak, nonatomic) IBOutlet UIImageView *inProImageView;

@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self showProgressHUD];
    
    typeof (self) WeakSelf = self;
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:30 repeats:NO block:^(NSTimer * _Nonnull timer) {

        [WeakSelf hideProgressHUD];

        WeakSelf.checkButton.hidden = NO;
        WeakSelf.checkImage.hidden = NO;

        self.inProgressImageView.hidden = YES;
        self.inProImageView.hidden = YES;
        self.completeImageView.hidden = NO;
    }];

    [timer class];
}
- (IBAction)buttonClick:(UIButton *)sender {
    if (self.block) {
        self.block();
    }
}

- (void)finishFunc
{
    [self hideProgressHUD];
    
    self.checkButton.hidden = NO;
    self.checkImage.hidden = NO;

    self.inProgressImageView.hidden = YES;
    self.inProImageView.hidden = YES;
    self.completeImageView.hidden = NO;
}
@end
