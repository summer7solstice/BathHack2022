//
//  TestResultViewController.h
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef void(^ActionBlock)(void);
@interface TestResultViewController : UIViewController
@property (nonatomic, assign) BOOL haveCravity;
@property(nonatomic, copy) ActionBlock block0;
@property(nonatomic, copy) ActionBlock block1;
@end

NS_ASSUME_NONNULL_END
