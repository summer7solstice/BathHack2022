//
//  UITextField+Category.h
//  Danfo
//
//  Created by 黄晓军 on 2020/3/16.
//  Copyright © 2020 xjhuang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (Category)
@property (nonatomic, strong) IBInspectable UIColor *placeHolderColor;
@end

NS_ASSUME_NONNULL_END
