//
//  NSObject+HUD.h
//  ZNZNew
//
//  Created by xjhuang on 2018/7/11.
//  Copyright © 2018年 xjhuang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MBProgressHUD.h"
@interface NSObject (HUD)
/* HUD */
- (void)showToastHUD:(NSString*)string;
/* ProgressHUD */
- (void)showProgressHUD;
- (void)hideProgressHUD;
@end
