//
//  AppDelegate+RootViewController.m
//  AWJ
//
//  Created by 黄晓军 on 2019/7/9.
//  Copyright © 2019 xjhuang. All rights reserved.
//

#import "AppDelegate+RootViewController.h"
#import "BaseTabBarController.h"

@implementation AppDelegate (RootViewController)

- (void)initializeRootViewControllerWithApplication:(UIApplication *)application
{
    UIWindow *window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    if (@available(iOS 13.0, *)) {
        window.overrideUserInterfaceStyle = UIUserInterfaceStyleLight;
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDarkContent;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    }
    self.window = window;
    
    BaseTabBarController *tabVC = [BaseTabBarController new];
    self.window.rootViewController = tabVC;
    
//    NSInteger flag = [[NSUserDefaults standardUserDefaults] integerForKey:@"userLogin"];
    
//    if (flag)
//    {
//        // already loged in
//        self.window.rootViewController = [BaseTabBarController new];
//    }
//    else
//    {
//        // to log in
//    }
    
    [self.window makeKeyAndVisible];
}
@end
