//
//  SetViewController.m
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import "SetViewController.h"
#import "ViewController.h"
#import "AppDelegate.h"
@interface SetViewController ()

@end

@implementation SetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}
- (IBAction)btnClick:(UIButton *)sender {
    [self showToastHUD:@"Still developing."];
}

- (IBAction)logoutButtonClick:(UIButton *)sender {
    ViewController *vc = kMainStoryboardWithID(@"ViewController");
    AppDelegate *dele = [UIApplication sharedApplication].delegate;
    dele.tabbarController = nil;
    [self restoreRootViewController:vc];
}

@end
