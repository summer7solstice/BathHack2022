//
//  DataCell.m
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import "DataCell.h"

@implementation DataCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
