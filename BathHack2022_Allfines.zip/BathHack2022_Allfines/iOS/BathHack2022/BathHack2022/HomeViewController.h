//
//  HomeViewController.h
//  BathHack
//
//  Created by xjhuang on 02/04/2022.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
