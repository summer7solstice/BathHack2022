//
//  HomeViewController.m
//  BathHack
//
//  Created by xjhuang on 02/04/2022.
//

#import "HomeViewController.h"
#import "DFBlunoManager.h"
#import "TestViewController.h"
#import "TestResultViewController.h"
#import "AppDelegate.h"

@interface HomeViewController ()<DFBlunoDelegate>
@property (weak, nonatomic) IBOutlet UIView *view0;
@property (weak, nonatomic) IBOutlet UIView *view1;

@property(strong, nonatomic) DFBlunoManager* blunoManager;
@property(strong, nonatomic) DFBlunoDevice* blunoDev;

@property (weak, nonatomic) IBOutlet UIImageView *signImageView;
@property (weak, nonatomic) IBOutlet UITextField *mTf;

@property (nonatomic, assign) BOOL isControl;
@property (nonatomic, assign) BOOL isShow;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topCons;
@property (nonatomic, copy) NSString *material;

@property (weak, nonatomic) IBOutlet UIImageView *materialImageView;
@property (nonatomic, strong) TestViewController *testVc;
@end

@implementation HomeViewController
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.view0.layer.shadowColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:0.38].CGColor;
    self.view0.layer.shadowOffset = CGSizeMake(0,3);
    self.view0.layer.shadowOpacity = 1;
    self.view0.layer.shadowRadius = 10;
    self.view0.layer.cornerRadius = 8;
    
    self.view1.layer.shadowColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:0.38].CGColor;
    self.view1.layer.shadowOffset = CGSizeMake(0,3);
    self.view1.layer.shadowOpacity = 1;
    self.view1.layer.shadowRadius = 10;
    self.view1.layer.cornerRadius = 8;
}

- (void)viewDidLoad {
    [super viewDidLoad];


}
-(void)didDiscoverDevice:(DFBlunoDevice*)dev
{
    DFBlunoDevice* device = dev;
    if (self.blunoDev == nil)
    {
        self.blunoDev = device;
        [self.blunoManager connectToDevice:self.blunoDev];
    }
    else if ([device isEqual:self.blunoDev])
    {
        if (!self.blunoDev.bReadyToWrite)
        {
            [self.blunoManager connectToDevice:self.blunoDev];
        }
    }
    else
    {
        if (self.blunoDev.bReadyToWrite)
        {
            [self.blunoManager disconnectToDevice:self.blunoDev];
            self.blunoDev = nil;
        }
        
        [self.blunoManager connectToDevice:device];
    }
}

#pragma mark- DFBlunoDelegate

-(void)bleDidUpdateState:(BOOL)bleSupported
{
    if(bleSupported)
    {
        [self.blunoManager scan];
    }
}

-(void)readyToCommunicate:(DFBlunoDevice*)dev
{
    self.blunoDev = dev;
//    self.lbReady.text = @"Ready!";
}
-(void)didDisconnectDevice:(DFBlunoDevice*)dev
{
//    self.lbReady.text = @"Not Ready!";
}
-(void)didWriteData:(DFBlunoDevice*)dev
{
    
}
#pragma mark - Actions
- (IBAction)selButtonClick:(UIButton *)sender {
    self.isShow = !self.isShow;
    
    if (self.isShow) {
        self.materialImageView.hidden = YES;
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
        } completion:^(BOOL finished) {
            self.topCons.constant = 10;
            [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveLinear animations:^{
                self.view1.hidden = NO;
                [self.view layoutIfNeeded];
            } completion:^(BOOL finished) {
                
            }];
        }];
    }
    else
    {
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
        } completion:^(BOOL finished) {
            self.topCons.constant = -200;
            [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveLinear animations:^{
                self.view1.hidden = YES;
                [self.view layoutIfNeeded];
            } completion:^(BOOL finished) {
                
            }];
        }];
    }
    
}
- (IBAction)signButtonClick:(UIButton *)sender {
    self.signImageView.hidden = !self.signImageView.hidden;
}
- (IBAction)controlButtonClick:(UIButton *)sender {
    self.isControl = !self.isControl;
}
- (IBAction)btnClick:(UIButton *)sender {
    switch (sender.tag) {
        case 100:
            self.material = @"Tree";
            self.materialImageView.hidden = NO;
            self.materialImageView.image = [UIImage imageNamed:@"IMG_0325 2"];
            break;
        case 101:
            self.material = @"Tooth";
            self.materialImageView.hidden = NO;
            self.materialImageView.image = [UIImage imageNamed:@"Tooth 1"];
            break;
        case 102:
            self.material = @"Pipe";
            self.materialImageView.hidden = NO;
            self.materialImageView.image = [UIImage imageNamed:@"pipe 1"];
            break;
        case 103:
            self.material = @"Others";
            self.materialImageView.hidden = NO;
            self.materialImageView.image = [UIImage imageNamed:@"Qsmark 1"];
            break;
            
        default:
            break;
    }
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
    } completion:^(BOOL finished) {
        self.topCons.constant = -200;
        [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveLinear animations:^{
            self.view1.hidden = YES;
            [self.view layoutIfNeeded];
        } completion:^(BOOL finished) {
            
        }];
    }];
    
    self.mTf.text = self.material;
}

- (IBAction)startButonClick:(UIButton *)sender {
    if (!self.material.length) {
        [self showToastHUD:@"Select the mateial type please."];
        return;
    }
    self.blunoManager = nil;
    // start scan
    self.blunoManager = [DFBlunoManager sharedInstance];
    self.blunoManager.delegate = self;
    [self.blunoManager scan];
    
    TestViewController *vc = kMainStoryboardWithID(@"TestViewController");
    [self addChildViewController:vc];
    [self.view addSubview:vc.view];
    self.testVc = vc;
    
}

-(void)didReceiveData:(NSData*)data Device:(DFBlunoDevice*)dev
{
    NSString *wholeString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    if ([wholeString isEqualToString:@"loading\r\n"]) {
        return;
    }
    
    NSString *dis = @"None";
    NSString *flag = @"NO";
    if (![wholeString isEqualToString:@"no"]) {
        dis = wholeString;
        flag = @"YES";
    }
    
    NSString *dateStr = [DateUtil getStringFromDate:[NSDate date] format:@"yyyy-MM-dd"];
    NSDictionary *dict = @{
        dateKey : dateStr,
        mKey : self.material,
        cKey : flag,
        dKey : dis
    };
    
    [[DataManager sharedManager] appendNewData:dict];
    
    [self.testVc finishFunc];
    
    typeof (self) WeakSelf = self;
    self.testVc.block = ^{
        [WeakSelf.navigationController popViewControllerAnimated:YES];
        [self.testVc.view removeFromSuperview];
        
        TestResultViewController *resVc = kMainStoryboardWithID(@"TestResultViewController");
        [WeakSelf addChildViewController:resVc];
        [WeakSelf.view addSubview:resVc.view];
        resVc.haveCravity = [flag isEqualToString:@"NO"] ? NO :YES;
        
        resVc.block0 = ^{
            [WeakSelf.navigationController popViewControllerAnimated:YES];
            [resVc.view removeFromSuperview];
            [[(AppDelegate *)[UIApplication sharedApplication].delegate tabbarController] setSelectedIndex:1];
        };
        
        resVc.block1 = ^{
            [resVc.view removeFromSuperview];
            [WeakSelf.navigationController popViewControllerAnimated:YES];
        };
    };
}
@end
