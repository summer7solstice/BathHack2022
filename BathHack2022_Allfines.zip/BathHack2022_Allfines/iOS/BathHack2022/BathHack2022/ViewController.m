//
//  ViewController.m
//  BathHack2022
//
//  Created by xjhuang on 02/04/2022.
//

#import "ViewController.h"
#import "BaseTabBarController.h"
#import "AppDelegate.h"
#import "IQKeyboardManager.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *view0;
@property (weak, nonatomic) IBOutlet UIView *view1;
@property (weak, nonatomic) IBOutlet UITextField *tf0;
@property (weak, nonatomic) IBOutlet UITextField *tf1;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSUserDefaults standardUserDefaults] setValue:nil forKey:kDataKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self.view0 xj_radius:5 borderWidth:3 borderColor:HexColor(@"#63351C")];
    [self.view1 xj_radius:5 borderWidth:3 borderColor:HexColor(@"#63351C")];
}
- (IBAction)logInButtonClick:(UIButton *)sender {
    if (!self.tf0.text.length)
    {
        [self showToastHUD:@"Please input username."];
        return;
    }
    if (!self.tf1.text.length)
    {
        [self showToastHUD:@"Please input password."];
        return;
    }
    
    BaseTabBarController *tabVc = [[BaseTabBarController alloc] init];
    AppDelegate *dele = [UIApplication sharedApplication].delegate;
    dele.tabbarController = tabVc;
    [self restoreRootViewController:tabVc];
}
/// IQKeyboardManager
- (void)initializeIQKeyboardManager
{
    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
    manager.enable = YES;
    manager.shouldResignOnTouchOutside = YES;
    manager.shouldToolbarUsesTextFieldTintColor = YES;
    manager.enableAutoToolbar = YES;
}
@end
