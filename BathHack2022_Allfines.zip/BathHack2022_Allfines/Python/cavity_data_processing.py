# Module Importation
import pandas as pd
import numpy as np

# Function to obtain boundary position:
def boundary(values, history, log):
    cd_csv, history_csv, logbook_csv = pd.read_csv(values), pd.read_csv(history), pd.read_csv(log)
    cd, history, logbook = pd.DataFrame(cd_csv), pd.DataFrame(history_csv), pd.DataFrame(logbook_csv)

    #* Calculating sound propagation time
    cd['x'] = cd
    cd['x'] = cd * 10 #* cm conversion
    cd['n'] = np.linspace(0, len(cd['x']), len(cd['x']))

    while True:
        #* Finding median
        material = str(input('What material are you testing?: ')).title()
        spikes = []
        for value in cd['x']:
            spikes.append(value)

        if len(spikes) > 0: #* If this is the case, cavity found. 
            median = np.median(spikes)
            #mean = mean.round(mean, 2)
            print(f'Cavity = {median}')
            newrow = {'Material':material, 'Cavity Found?':'Yes', 'Cavity Distance/cm':median}
            history = history.append(newrow, ignore_index=True)

        else:
            print('Cavity Not Found')
            newrow = {'Material':material, 'Cavity Found?':'No', 'Cavity Distance/cm':'-'}
            history = history.append(newrow, ignore_index=True)
        
        #* User asked if they want to repeat this trial
        answer = str(input('Do you want to repeat this trial (y/n)? ')).lower()
        if answer == 'n':
            logbook = logbook.append(newrow, ignore_index=True)

        ans = str(input('Would you like to see your logbook (y/n)? ')).lower()
        if ans == 'y':
            print(logbook)

#Running function and displaying graph
boundary('cavity_data.csv', 'trial_history.csv', 'cavity_logbook.csv')